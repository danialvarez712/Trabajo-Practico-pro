#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include <ctime>
#include"juego.h"

void menu();
void juego();




#endif // MENU_H_INCLUDED
